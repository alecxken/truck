/**
 * A no-operation function
 */
export declare const noop: () => void;
